# 366 actual readback v2: task-scoped process interpretation

## 1. Requirements

Keep first readback failure/source/owner unchanged. No physical tree was inventoried in first attempt. ROOT clarified no active task Game/recorded PID/PGID, not universal system proc visibility. Current sandbox denies cwd/fd/maps for unrelated platform processes; record these gaps instead of claiming complete system visibility. No pool mutation/READY/process launch.

## 2. Design

Reuse the exact scanner and old target sources. Save exact original process inspector results before any interpretation. Independently read current stat/comm/cmdline/UID, require recorded parse/native cleanup live_remaining empty and no live PID/PGID from those records, no live Godot/Xvfb executable, no readable project references. Acquire the existing pool lock exclusively using a read-only file descriptor while scanning; never alter its bytes/metadata. Unknown inaccessible task identity blocks. All proc gaps remain disclosed and are not recast as full inspection success.

## 3. Realize

The new script changes output location, adds task-scoped process checks, read-only flock and gap metadata. All actual inventories, hash/mode/mtime comparison, failed capsule set, old retained/driver, saved overlay and state checks stay identical. First failure remains at old directory; diagnosis remains in separate frozen directory. No successful physical scan is repeated because first stopped beforehand.

## 4. Acceptance criteria

All full tree targets match actual direct scans; state is unchanged failed; known task groups absent/live0 and lock available. Whole_system_proc_complete remains false, with permission gaps preserved. Reserved PASS concerns restored targets and bounded no-active-task scope only. Actual READY/newattempt remain ROOT later gates.
