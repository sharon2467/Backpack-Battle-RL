# 366 independent physical restored-pool readback

## 1. Requirements

Read the actual existing pool/project and pool/data without mutation and compare their complete path/kind/bytes/SHA256/mode/mtime trees with the old026 compaction project-files/staged-inputs targets. Verify baseline, previous retained/driver evidence, the saved027 failure sources/log/UI/preservation, unchanged failed state and no live Game references. No recovery/commit API, READY write, process launch, Godot, input projection or model is authorized.

## 2. Design

Freeze the independent scanner, SOURCE provenance and exact expected manifest descriptors before inventory. The engineering restore receipt supplies only the required wire binding and is never the target truth. Direct filesystem inventories derive bytes and metadata independently; old immutable bundle manifests and the already frozen failed-run capsule supply expected facts. Business observation files are hashed as opaque bytes, not decoded. All actual-root paths are provenance, never owner leaves. Output manifests and owner remain inside the repository.

The scanner opens regular files with O_NOFOLLOW, rejects hardlinks/special permissions/xattrs in strict project trees, checks file identity before/after hashing, preserves sorted recursive ordering and directly emits the existing manifest schema. Previous retained user trees use the established relaxed special-node representation. SOURCE-exact read-only process inspection checks references to pool/baseline/failed/previous roots. No new process is created.

## 3. Realize

`phase366_independent_readback.py`: verify presealed contract and ROOT restore authorization; check engineering receipt bindings against that authorization and old target descriptors. Install an audit hook rejecting writes outside own outputs and all process/network launches. Inventory project, staged data and baseline; emit actual inventories before comparison. Inventory old retained output/data/user and driver against old bundle manifests. Hash every preserved failed-run output/data leaf against the immutable repo failure owner and reject unknown/missing leaves; hash its user subtree without decoding or claiming a historic user-tree target. Independently validate saved failed overlay members against the failed manifest and recorded ZIP identity, without extracting. Check state bytes equal the saved failed state before/after; inspect live process references; reread small target/config pins at finish. Persist first failure and all successful observations if anything differs.

## 4. Acceptance criteria

Only exact full-tree equality qualifies for `INDEPENDENT365_RESTORED_POOL_EXACT_TARGET_READBACK_PASS`. Required roots/map/source/targets/failed_state values match engineering receipt wire fields but actual inventories come from direct reads. Project/staged actual manifests are owned repository leaves. Record actual counts/bytes, metadata equality, opaque retained coverage and process inspection gaps honestly. Any discrepancy blocks READY; no automatic recovery, retry or mutation. Root must separately authorize and perform READY commit after reading this independent owner.
