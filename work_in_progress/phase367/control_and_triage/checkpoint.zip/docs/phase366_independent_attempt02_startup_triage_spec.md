# 366 attempt02 independent startup control/source triage

## 1. Requirements

Read only attempt02 process/control/fixture/UI evidence and frozen365 collector/359 sink plus existing Godot SOURCE. Do not launch a language probe, Game, model, recovery or READY action; do not modify failed pool, fixtures, seeds or old evidence. Distinguish observed failure from SOURCE-derived possible/necessary guard failure and unrecorded predicate state. No battle expected semantics are read.

## 2. Design

Preserve bounded local byte-identical copies of controls, logs and lawful UI, with actual external paths recorded only as provenance. Decode only startup control DTOs and the UI carrier; never create missing inputs. Extract exact collector/sink/Godot SOURCE spans with original pins. Existing Object signal-map ordering is a SOURCE lemma, not a new VM measurement. Runtime connection rows/IDs and guard returns are missing and must remain unknown.

## 3. Realize

The one stdlib triage script checks process_result/source-partition primary and secondaries; counts existing UI records and first/last kinds without modifying raw rows; checks setup steps/new-item state and logs. It emits a source control chain for ensure_source_window/attach/check/begin_fixture_window, a bounded SOURCE-only ordering witness with illustrative IDs explicitly not native evidence, and an exact missing-diagnostic matrix. It records any targeted SOURCE lookup errors; it does not retry native operations. Final owner references only immutable repository leaves/copies and is actually read back.

## 4. Acceptance criteria

Finding must state battle not started, capture incomplete, no model/projection/new processes/pool changes. No claim of illegal geometry from generic placement failure. UI open proves an earlier successful open, not every later flag. Connection-order predicate/actual rows were not saved on failure; if SOURCE ordering shows a structural conflict, label it SOURCE_DERIVED and retain actual guard identity as unobserved. Recommend only bounded primitive diagnostic/source correction scope, never fixture/seed changes or invented input values. Freeze finding/owner and stop writing.
