import ast,datetime,json,os
from pathlib import Path
r=Path(__file__).resolve().parents[1];d=r/"data/phase366-independent-process-diagnostic"
def require(v,m):
 if not v:raise ValueError(m)
s=r/"data/phase365-independent-source-review/SOURCE/compaction.py"
t=ast.parse(s.read_text());ns=dict(Path=Path,os=os,json=json,datetime=datetime,require=require)
exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ("stamp","process_check")],type_ignores=[]),"<read-only-inspector>","exec"),ns)
c=json.loads((r/"data/phase366-actual-pool-restore/restore-authorization.json").read_text())
v=ns["process_check"](Path(c["roots"]["pool"]))
for row in v["inspection_gaps"]:
 p=Path("/proc")/str(row["pid"])
 for name in ("status","comm","cmdline"):
  try:row[name]=(p/name).read_bytes().decode(errors="replace").replace("\0"," ")
  except OSError as exc:row[name+"_error"]=repr(exc)
with (d/"diagnostic.json").open("x") as f:json.dump(v,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps(v))
