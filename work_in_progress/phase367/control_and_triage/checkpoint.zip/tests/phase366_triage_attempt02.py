"""Read-only attempt02 startup control triage; no SUT imports or process launch."""
from pathlib import Path
import collections
import hashlib
import json

R=Path(__file__).resolve().parents[1]
D=R/'data/phase366-independent-attempt02-triage'
RUN=Path('/workspace/native-combat-20261013/runs/original027-king-single-A-20261025-attempt02')

def pin(path):
    raw=path.read_bytes();return dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def desc(path):return dict(path=str(path.relative_to(R)),**pin(path))
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
def read(path):return json.loads(path.read_text())
def spans(path,ranges):
    lines=path.read_text().splitlines()
    return dict(source=desc(path),spans=[dict(start=a,end=b,text='\n'.join(lines[a-1:b])+'\n') for a,b in ranges])

def main():
    contract=read(D/'execution-contract.json')
    for row in contract['files']:assert desc(R/row['path'])==row
    (D/'controls').mkdir()
    origins=[]
    for relative in contract['run_controls']:
        original=RUN/relative;target=D/'controls'/relative.replace('/','__')
        with target.open('xb') as stream:stream.write(original.read_bytes())
        assert pin(original)==pin(target)
        origins.append(dict(original=str(original),local=desc(target)))
    def control(relative):return read(D/'controls'/relative.replace('/','__'))
    process=control('output/process_result.json');partition=control('output/source-partition.json')
    first=control('output/capture/collector-first-failure.json');setup=control('output/capture/player_setup_evidence.json')
    assert process['primary_failure']['control']==first==partition['primary_failure']['control']
    assert first['code']=='native player placement rejected' and first['stage']=='player_setup'
    assert process['capture_complete'] is False and process['exit_code']==2 and process['source_changes_after_run']==[]
    assert setup['new_items']==[] and [row['name'] for row in setup['steps']]==['removed_wait','discarded_wait']
    ui_path=D/'controls/output__capture__king-ui-authority.jsonl'
    ui=[json.loads(line) for line in ui_path.read_text().splitlines()]
    assert ui and ui[0]['kind']=='open' and all(row['sequence']==i for i,row in enumerate(ui))
    ui_summary=dict(rows=len(ui),kind_counts=dict(collections.Counter(row['kind'] for row in ui)),
        site_counts=dict(collections.Counter(row['site'] for row in ui)),first=ui[0],
        last_metadata={key:ui[-1][key] for key in ('sequence','kind','site','physics_frame','idle_frame','in_physics')},
        raw_identity=pin(ui_path),all_sequence_contiguous=True,
        scope='UI carrier startup only; open is observed earlier, current observer flags are not a direct failure-time sample.')
    save(D/'ui-startup-summary.json',ui_summary)
    collector=R/'data/phase365-control-recovery-source/collector.gd'
    sink=R/'data/phase359-king-producer-source/after-source/native_random_observer_sink_v7.gd'
    ocpp=R/'data/phase184-ranger-idle-sync-source/source/object.cpp'
    oh=R/'data/phase184-ranger-idle-sync-source/source/object.h'
    main=R/'data/phase027-implementation-design/full-source/upstream/main/main.cpp'
    source=[spans(collector,[(1,2),(92,96),(122,125),(154,161),(275,305),(354,373),(773,785),(808,867)]),
        spans(sink,[(50,79),(845,867),(1000,1010),(1198,1206)]),
        spans(oh,[(450,476)]),spans(ocpp,[(1190,1210),(1329,1348),(1418,1427),(2016,2028)]),
        spans(main,[(1889,1903),(1995,2044)])]
    save(D/'source-chain.json',source)
    # Illustrative SOURCE key-order witness, NOT invented runtime IDs/rows or a VM test.
    witness=sorted([dict(target=10,method='observe'),dict(target=10,method='on_idle_source_cut'),dict(target=20,method='clock_idle_signal')],key=lambda row:(row['target'],row['method']))
    ci=next(i for i,row in enumerate(witness) if row['method']=='on_idle_source_cut')
    si=next(i for i,row in enumerate(witness) if row['method']=='clock_idle_signal')
    assert ci<si and ci!=si+1
    save(D/'source-order-witness.json',dict(classification='SOURCE_DERIVED_ILLUSTRATIVE_NOT_NATIVE_OR_VM',rows=witness,
        actual_runtime_ids_supplied=False,sink_index=si,collector_index=ci,required_adjacency=False,
        lemma='Object::Signal::Target orders target ObjectID then method; emitter and connection list traverse VMap by that key. MainLoop SceneTree is instanced before autoload Nodes; ObjectDB IDs increment at construction. Therefore SceneTree collector target sorts before later autoload sink, not after it. connect() call timing is not this ordering authority.',
        missing_runtime_evidence='Actual get_signal_connection_list rows and SceneTree/sink IDs were not recorded; this does not identify which ensure_source_window predicate actually returned false in attempt02.'))
    missing=[
        dict(field='observer present / failed / first_error / ui_opened / ui_closed / closed / configured',status='NO_FAILURE_TIME_CARRIER',source='ensure_source_window and begin_fixture_window guards'),
        dict(field='source_listener_attached / is_connected(clock_idle_signal) / connect result',status='NO_FAILURE_TIME_CARRIER',source='attach_source_listener'),
        dict(field='complete connection rows, target type+ID, method, flags, duplicate counts and both indices',status='NOT_SAVED_ON_FAILURE',source='check_source_listener_order assigns source_connection_order only after all guards pass'),
        dict(field='begin_fixture_window actual invocation/return and fixed-slot comparison',status='NO_FAILURE_TIME_CARRIER',source='called only after successful attachment/order check'),
        dict(field='first item book/descriptor/instantiate/geometry check actually reached',status='NOT_DIRECTLY_RECORDED',source='new_items appended after successful placement; empty list alone does not uniquely locate prior false branch')]
    save(D/'missing-diagnostic-matrix.json',missing)
    finding=dict(schema='phase366-attempt02-independent-startup-triage/1',status='STARTUP_FAILURE_CONFIRMED_SOURCE_LISTENER_ORDER_CONFLICT_AND_DIAGNOSTIC_GAP',
        observed=dict(primary=first,exit_code=process['exit_code'],process_clean_exit=process['process_clean_exit'],
            capture_complete=False,source_changes=[],battle_started=False,setup_steps=[row['name'] for row in setup['steps']],
            new_items=[],setup_evidence_errors=setup['errors'],lawful_missing=partition['lawful_inputs_missing'],
            validation_secondary=True,first_control_preserved=True,UI_open_record=True),
        source_derived=dict(first_guard_before_layout='place_player_items immediately calls ensure_source_window before any ItemBook/instantiate/geometry work.',
            listener_order_conflict='Collector connects on_idle_source_cut to SceneTree self; ObjectID-key ordering places that earlier SceneTree target before later sink autoload target, contradicting required sink+1 condition. This is a structural SOURCE control defect conditional on reaching the order check, not observed connection rows.',
            old_input_helpers_and_fixed_fixture='No fixture/seed change is supported. Successful config/preflight/control setup advanced beyond attempt01 startup failure.',
            rejection_propagation='attach marks source_listener_attached=true before check; false check propagates immediately through ensure/place and generic collector fail. The evidence lacks its return predicate.',
            observer_failure_visibility='Sink.fail normally writes observer7_failure.json with first_error; that file is absent in current capture. Absence alone cannot prove every later observer flag; collector observe checks observer.failed at idle-entry, not as a saved failure snapshot.'),
        not_claimed=['Actual false predicate uniquely observed','Layout geometry invalid','Actual successful connection adjacency','Observer failure-time state reconstructed','Missing9 inputs usable','Battle/native/model acceptance'],
        minimum_next_SOURCE_scope=[
            'Persist one bounded primitive source-window diagnostic before every guard false: observer existence/IDs/flags/first_error, listener attachment and clock is_connected, connect return, complete connection rows/indices/duplicates/flags and exact failure reason.',
            'Snapshot connection rows before all early returns, not only on successful check; preserve current first failure and raw stamp/sequence.',
            'Correct receiver/order design using actual Godot ObjectID map semantics while retaining same-idle sink-after/preinternal requirement; changing connect timing alone is not a proof. Independently SOURCE-review and use any future root-authorized targeted validation; no new validation run here.',
            'Keep fixed layout/seed, business effects/getStats, runtime356 and reader361 gates unchanged. No missing input is synthesized from controls or expected.'
        ],
        missing_diagnostics=desc(D/'missing-diagnostic-matrix.json'),source_chain=desc(D/'source-chain.json'),
        UI_summary=desc(D/'ui-startup-summary.json'),source_witness=desc(D/'source-order-witness.json'),
        source_read_diagnostics=[dict(path='data/phase184-ranger-idle-sync-source/source/main.cpp',status='MISSING_TARGETED_LOOKUP',resolution='existing indexed phase027 upstream/main/main.cpp'),
            dict(path='data/phase027-implementation-design/full-source/*json',status='NO_GLOB_MATCH',resolution='source-ledger.json/owned-files.json are at parent phase027 directory')],
        oracle_probes=0,Godot_processes=0,actual_Game_processes=0,native_battles=0,models=0,projection_calls=0,
        pool_operations=0,new_attempts=0,fixture_or_seed_changes=0,no_more_writes=True)
    save(D/'finding.json',finding);save(D/'origin-pins.json',dict(files=origins))
    for row in contract['files']:assert desc(R/row['path'])==row
    for row in origins:assert pin(Path(row['original']))=={k:row['local'][k] for k in ('size','sha256')}
    selected=[p for p in D.rglob('*') if p.is_file()]
    selected+=[R/row['path'] for row in contract['files']]
    save(D/'owned-files.json',dict(schema='phase366-attempt02-triage-owner/1',files=[desc(p) for p in sorted(set(selected))],external_paths_provenance_only=True,no_more_writes=True))
    owner=read(D/'owned-files.json')
    for row in owner['files']:assert desc(R/row['path'])==row
    print(json.dumps(dict(finding=desc(D/'finding.json'),owner=desc(D/'owned-files.json'),leaves=len(owner['files']),bytes=sum(row['size'] for row in owner['files']),status=finding['status'])))

if __name__=='__main__':main()
