# Phase467 controlled original King/basic case

## Requirements

Execute only the conditionally authorized NATIVE-028-KING-BASIC-A fixed26-slot case in the existing environment/program/pool, after463 observer and465 host acceptance and actual space/predecessor gates. One parse≤30s, then at most one original battle≤300s; parse failure means no battle. Preserve first failure and all raw data. No reseed, relayout, old case rerun, model/input build/Expected comparison inside this host operation.

## Design

Use frozen tests/phase464_oracle_host_v2.py and phase464 storage, actual462v3 tuple/78payloads812880B, actual independent463 and465 reviews. Root issues one closed phase464-root-oracle-acceptance/1 config with actual descriptor hashes; models_allowed/input_builds_allowed/expected_comparison_allowed are INT0. Resource pins reuse the actual six401 sources/binaries only, verified on current paths, not its historical permissions. Relocations remain the actual existing empty map. The existing host performs fresh resource/space/complete predecessor checks before/under lease; its exact process monitor performs the permitted parse and native invocation. No new environment/program/account/security setting.

The fixed run is /workspace/native-combat-20261013/runs/original028-king-basic-A-single-001. Lock-held state preimage is sampled before busy; state and two staged fixture images/metadata are durably backed up before observer reset/install. Old patch/marker and all installed-source preimages are journaled. After archive, final pool state remains failed/PENDING_INDEPENDENT_PREDECESSOR_RESTORE. Separate exact predecessor restoration and independent physical readback precede Root READY; no automatic old READY paste.

## Realize

- prepare_config(): read actual shape contract and frozen owner; bind actual review descriptors/status/source-freeze and explicit resource pins; preserve source identities. Do not create a passing review or use old review authorization. Write a unique config, its SHA, operation scope and exact argv before launch.
- prelaunch(): read statvfs on the actual shared filesystem; require free≥5905580032B, no overlapping live task operation and absent unique run. Source/host gates perform authoritative actual checks; no historical READY boolean substitution. If insufficient, stop native operation and retain evidence; only independently reproducible task temporary files may be reclaimed, never originals/unique/unverified backups.
- execute_once(): invoke the already accepted host with explicit source/task/baseline/pool/runs/config descriptors and --execute once. Capture stdout/stderr/return code/elapsed and started/completed receipts in a unique Root directory. No retry on any failure. The two OS Godot launches and monitor grace are separately recorded; ordinary host I/O/archiving time is not falsely called a330-second overall hard bound.
- preserve_and_restore(): retain installed-source journals, predecessor-control images, raw complete/partial capture, process/terminal controls and diagnostics. Keep the original business Expected payloads opaque. Derive the smallest exact predecessor restoration from the real journals/backups and previously verified actual inventory; independently verify baseline/project/staged/run evidence before Root commits READY. This spec does not authorize a blind restore or evidence cleanup.
- subsequent_input_model_compare(): separately accept lawful INPUT and common-source rule premises on actual new identities. Seal one new Tape-model output before independent business Expected reads; compare the unchanged eight business sections. This later sequence is authorized in scope but not executed by the oracle-only Root config.

## Acceptance Criteria / Tests

463 and465 owned Source receipts exact; Source/runtime resource hashes match; current free/predecessor gate passes; one parse and at most one battle only; no model or input build inside host. Raw/partial evidence and exact installation journals preserved even on failure, no fabricated success or clean-exit claim. Independent restoration readback and Root READY are distinct from semantic capture success. Unhit business branches remain NOT_HIT without reroll. No generalKing admission, support count increase, production seed parity or whole-engine/RL completion follows.
