# Phase467 complete native capsule preservation

## Requirements
Preserve the one completed native run and Root invocation/config/diagnostics from existing files, without executing archived code or another game. Keep unique originals and failures. Public backup excludes credentials and unrelated private material; known baseline credential scripts are not in the selected driver map.

## Design
Create one compressed evidence capsule from the dedicated fixed run plus explicit Root467 evidence and execution specs. No baseline/pool/fullGame copy. Enumerate ordinary single-link files only with safe relative archive names; stable before/after stat, exact SHA/size and mode/mtime inventories. Scan common secret patterns without printing values. Existing evidence-only401 restore_capture.py is reused byte-exact; it verifies CRC/all payload hashes before extraction and does not execute code or restore a pool. Its receipt is byte-level extraction, not freshOS/physical-ready proof.

## Realize
make_capsule(): enumerate fixed run and explicit Root467 subtree/specs, reject links and duplicate archive names, stream/read each stable file into ZIP_DEFLATED while recording identity. Preserve directory metadata as manifest evidence. Check ZIP CRC, entry set and individual decompressed SHA after closing. Write adjacent CAPSULE.json with zip identity, complete member inventory and explicit no-model/no-semantic-admission status. Keep original run untouched. Publication copies only the capsule, manifest, exact old extraction helper and instructions; remote readback rechecks them without replaying any battle.

## Acceptance Criteria / Tests
All selected dedicated-run files and Root evidence are byte-covered, no secret-pattern hit, no known credential source/opaque companion included. ZIP CRC and every decompressed member SHA pass. A standalone remote manifest/capsule verifies without old cloud files; no additional game/model/Expected semantic comparison follows from archiving. Native complete capture and nonclean exit remain distinct; full joint Python comparison is pending.
